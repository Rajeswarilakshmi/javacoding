package com.codingbat;

public class Logic {

  /***
   * Problem Statement: https://codingbat.com/prob/p159531
   * @param cigars
   * @param isWeekend
   * @return
   */
  public boolean cigarParty(int cigars, boolean isWeekend) {
    return false;
  }
}
